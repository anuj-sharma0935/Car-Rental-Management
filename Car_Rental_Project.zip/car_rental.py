import pandas as pd
import matplotlib.pyplot as plt
import random

def addCar(df):
    code = int(input("Enter the car ID: "))
    name = input("Enter the car model name: ")
    price = int(input("Enter price per day (rental): "))
    qty = int(input("Enter the quantity available: "))
    brand = input("Enter the car brand: ")
    df.loc[code] = [name, price, qty, brand]
    print("\nCar Added Successfully!\n")

print("*" * 50)
print("\t\t Car Rental Management System")
print("*" * 50)

try:
    cars = pd.read_csv("cars.csv", index_col=0)
except FileNotFoundError:
    cars = pd.DataFrame(columns=["Model", "Price_per_day", "Quantity", "Brand"])
    cars.index.name = "Car_ID"

while True:
    print("Press 1 - Add a New Car")
    print("Press 2 - Show All Cars")
    print("Press 3 - Search for a Car")
    print("Press 4 - Delete a Car")
    print("Press 5 - Update Car Information")
    print("Press 6 - Rent Out a Car (Generate Bill)")
    print("Press 7 - Show Chart of Cars")
    print("Press 8 - Show Chart of Rentals")
    print("Press 9 - Quit")
    choice = int(input("Enter your choice: "))
    
    if choice == 1:
        addCar(cars)
    elif choice == 2:
        print("\n", "*" * 50)
        print(cars)
        print("*" * 50)
    elif choice == 3:
        car_id = int(input("Enter the car ID to search: "))
        if car_id in cars.index:
            print(cars.loc[car_id])
            print("\n")
        else:
            print("No car found with this ID.")
    elif choice == 4:
        car_id = int(input("Enter the car ID to delete: "))
        if car_id in cars.index:
            cars.drop(car_id, inplace=True)
            print("\nCar Deleted Successfully!\n")
        else:
            print("No car found with this ID.")
    elif choice == 5:
        car_id = int(input("Enter the car ID to update: "))
        if car_id in cars.index:
            name = input("Enter the updated model name: ")
            price = int(input("Enter the updated price per day: "))
            qty = int(input("Enter the updated quantity available: "))
            brand = input("Enter the updated car brand: ")
            cars.loc[car_id] = [name, price, qty, brand]
            print("\nCar Updated Successfully!\n")
        else:
            print("No car found with this ID.")
    elif choice == 6:
        print("\nAvailable Cars:")
        print("\n", "*" * 50)
        print(cars)
        print("*" * 50)
        car_id = int(input("Enter the car ID to rent out: "))
        if car_id in cars.index:
            days = int(input("Enter the number of days for the rental: "))
            if cars.loc[car_id, "Quantity"] > 0:
                amount = days * cars.loc[car_id, "Price_per_day"]
                print(f"Total Rental Amount: {amount}")
                name = input("Enter Customer Name: ")
                rental_date = input("Enter Rental Date: ")
                try:
                    rentals = pd.read_csv("rentals.csv", index_col="Rental_ID")
                except FileNotFoundError:
                    rentals = pd.DataFrame(columns=["Customer_Name", "Rental_Date", "Total_Amount", "Car_Model"])
                    rentals.index.name = "Rental_ID"
                
                rental_id = random.randint(1000, 9999)
                rentals.loc[rental_id] = [name, rental_date, amount, cars.loc[car_id, "Model"]]
                rentals.to_csv("rentals.csv")
                
                cars.loc[car_id, "Quantity"] -= 1
                print("\nCar Rented Out Successfully!\n")
            else:
                print("Sorry, this car is out of stock.")
        else:
            print("No car found with this ID.")
    elif choice == 7:
        plt.bar(cars["Model"], cars["Price_per_day"], color="blue")
        plt.title("Car Rental Price List")
        plt.xlabel("Car Model")
        plt.ylabel("Price per Day")
        plt.show()
    elif choice == 8:
        try:
            rentals = pd.read_csv("rentals.csv", index_col="Rental_ID")
            plt.bar(rentals["Customer_Name"], rentals["Total_Amount"], color="green")
            plt.title("Customer Rentals")
            plt.xlabel("Customer Name")
            plt.ylabel("Rental Amount")
            plt.show()
        except FileNotFoundError:
            print("No rental data available.")
    elif choice == 9:
        cars.to_csv("cars.csv")
        print("Thanks for using the Car Rental Management System!")
        print("Data Saved Successfully!")
        break
    else:
        print("Invalid choice. Please try again.")
